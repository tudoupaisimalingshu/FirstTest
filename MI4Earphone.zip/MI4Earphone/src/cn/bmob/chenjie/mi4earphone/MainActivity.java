package cn.bmob.chenjie.mi4earphone;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity
{
	boolean isHeadsetOn;
	AudioManager audioManager;
	BroadcastReceiver INSTANCE;
	TextView show;
	Button refresh;
	TextView ban;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		show = (TextView) findViewById(R.id.show);
		refresh = (Button) findViewById(R.id.refresh);
		ban = (TextView) findViewById(R.id.ban);
		test();
		refresh.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0)
			{
				test();
				Toast.makeText(MainActivity.this, "ˢ�³ɹ�", Toast.LENGTH_SHORT).show();
			}
		});
		INSTANCE = new HeadSetPlugListenner();
		IntentFilter filter = new IntentFilter();
		filter.addAction("android.intent.action.HEADSET_PLUG");
		// ����ʹ��Intent.ACTION_HEADSET_PLUG
		this.registerReceiver(INSTANCE, filter);
	}
	
	public void test()
	{
		audioManager = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE); 
		isHeadsetOn = audioManager.isWiredHeadsetOn();
		show.setText("��������:" + isHeadsetOn);
		if(isHeadsetOn)
		{
			banSpeaker();
		}
	}
	
	class HeadSetPlugListenner extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context context, Intent intent)
		{
			if (intent.hasExtra("state"))
			{
				if (intent.getIntExtra("state", 2) == 0)
				{
					// �γ�
					isHeadsetOn = false;
					show.setText("��������:" + isHeadsetOn);
				}
				else if (intent.getIntExtra("state", 2) == 1)
				{
					// ����
					isHeadsetOn = true;
					show.setText("��������:" + isHeadsetOn);
					banSpeaker();
				}
			}
		}
	}
	
	public void banSpeaker()
	{
		if(audioManager.isSpeakerphoneOn())
		{
			ban.setText("�������Ѵ�");
			audioManager.setSpeakerphoneOn(false);
			ban.setText("�ѽ���������");
		}
		ban.setText("������δ��");
	}
//	boolean isHeadsetOn = false;
//	String HEADSET_STATE_PATH = "/sys/class/switch/h2w/state";// ���������һ���ӿ�
//	int headsetState = 0;
//	int len = 0;try
//	{
//		FileReader file = new FileReader(HEADSET_STATE_PATH);
//		char[] buffer = new char[1024];
//		try
//		{
//			len = file.read(buffer, 0, 1024);
//		}
//		catch (IOException e)
//		{
//		}
//		headsetState = Integer.valueOf(new String(buffer, 0, len).trim());
//	}catch(
//	FileNotFoundException e)
//	{
//	}if(headsetState>0)
//	{// ������ֻ����ֵ��1����2������Ҳ�в����ֻ���100�࣬
//		// �ֱ��ʾ�������ӻ��߶�������˷綼����
//		isHeadsetOn = true;
//	}else
//	{// -1��������������ʾ�γ�
//		isHeadsetOn = false;
//	}
	
	@Override
	protected void onDestroy()
	{
		this.unregisterReceiver(INSTANCE);
	}
}
