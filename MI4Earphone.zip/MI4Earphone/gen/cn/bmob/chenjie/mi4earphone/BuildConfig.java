/** Automatically generated file. DO NOT MODIFY */
package cn.bmob.chenjie.mi4earphone;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}